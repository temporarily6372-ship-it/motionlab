# MotionLab - Stage 1

Kotlin + Jetpack Compose + Media3 (ExoPlayer, MediaCodec-backed). minSdk 29 (Android 10), targetSdk 34.

## Run
1. Android Studio Koala (2024.1.1) or newer, JDK 17 (bundled).
2. File > Open > select the `MotionLab` folder. Accept the Gradle sync (wrapper = Gradle 8.7; Android Studio
   generates gradlew if missing: Tools > "Gradle" or just sync).
3. Plug in the vivo V30 Pro (USB debugging on) and press Run.

## Stage 1 features
- Home screen: project list (persisted JSON), delete, thumbnails.
- New Project: orientation (portrait/landscape/square), aspect ratios, 720p/1080p/4K, 24/30/60 fps, live canvas preview.
- Editor: media import (system picker, videos + photos), media browser with thumbnails, real video preview (ExoPlayer),
  play/pause/seek with timecode, grid / center guides / safe margins, preview-quality selector,
  portrait and landscape layouts, pauses on background.

## Next stages
2 Timeline + edit engine, 3 OpenGL ES renderer + effects, 4 keyframes/graph editor, 5 audio/beats, 6 export (MediaCodec), 7 tracking (OpenCV).
