package com.motionlab.app.ui

import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.lifecycle.viewmodel.compose.viewModel
import androidx.navigation.NavType
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument
import com.motionlab.app.data.ProjectViewModel
import com.motionlab.app.ui.screens.EditorScreen
import com.motionlab.app.ui.screens.HomeScreen
import com.motionlab.app.ui.screens.NewProjectScreen

@Composable
fun MotionLabApp(vm: ProjectViewModel = viewModel()) {
    val nav = rememberNavController()
    val projects by vm.projects.collectAsState()

    NavHost(navController = nav, startDestination = "home") {
        composable("home") {
            HomeScreen(
                projects = projects,
                onNew = { nav.navigate("new") },
                onOpen = { nav.navigate("editor/$it") },
                onDelete = vm::delete
            )
        }
        composable("new") {
            NewProjectScreen(
                onBack = { nav.popBackStack() },
                onCreate = { name, aspect, res, fps ->
                    val p = vm.create(name, aspect, res, fps)
                    nav.navigate("editor/${p.id}") { popUpTo("home") }
                }
            )
        }
        composable("editor/{id}", arguments = listOf(navArgument("id") { type = NavType.StringType })) { entry ->
            val id = entry.arguments?.getString("id")
            val project = projects.firstOrNull { it.id == id }
            if (project != null) {
                EditorScreen(
                    project = project,
                    onImport = { vm.importMedia(project.id, it) },
                    onRemove = { vm.removeMedia(project.id, it) },
                    onBack = { nav.popBackStack() }
                )
            }
        }
    }
}
