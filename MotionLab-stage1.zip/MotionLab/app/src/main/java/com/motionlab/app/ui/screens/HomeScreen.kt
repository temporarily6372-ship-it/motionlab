package com.motionlab.app.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.motionlab.app.data.Project
import com.motionlab.app.ui.components.MediaThumb
import com.motionlab.app.ui.theme.MLColors
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun HomeScreen(
    projects: List<Project>,
    onNew: () -> Unit,
    onOpen: (String) -> Unit,
    onDelete: (String) -> Unit
) {
    var pendingDelete by remember { mutableStateOf<Project?>(null) }

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
        Spacer(Modifier.height(16.dp))
        Row(verticalAlignment = Alignment.CenterVertically) {
            Box(
                Modifier.size(44.dp).clip(RoundedCornerShape(13.dp))
                    .background(Brush.linearGradient(listOf(MLColors.Accent, MLColors.Accent2))),
                contentAlignment = Alignment.Center
            ) { Icon(Icons.Default.PlayArrow, null, tint = Color.White) }
            Spacer(Modifier.width(12.dp))
            Column {
                Text("MotionLab", style = MaterialTheme.typography.headlineSmall, fontWeight = FontWeight.Bold)
                Text("Professional video editor", style = MaterialTheme.typography.bodySmall, color = MLColors.Muted)
            }
        }
        Spacer(Modifier.height(22.dp))
        Button(
            onClick = onNew,
            modifier = Modifier.fillMaxWidth().height(56.dp),
            shape = RoundedCornerShape(16.dp)
        ) {
            Icon(Icons.Default.Add, null)
            Spacer(Modifier.width(8.dp))
            Text("New Project", fontWeight = FontWeight.SemiBold)
        }
        Spacer(Modifier.height(26.dp))
        Text("Projects", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.SemiBold)
        Spacer(Modifier.height(12.dp))

        if (projects.isEmpty()) {
            Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                Text("No projects yet. Tap New Project to start.", color = MLColors.Muted)
            }
        } else {
            LazyVerticalGrid(
                columns = GridCells.Adaptive(300.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(bottom = 24.dp)
            ) {
                items(projects, key = { it.id }) { p -> ProjectCard(p, { onOpen(p.id) }, { pendingDelete = p }) }
            }
        }
    }

    pendingDelete?.let { p ->
        AlertDialog(
            onDismissRequest = { pendingDelete = null },
            title = { Text("Delete project?") },
            text = { Text("\"${p.name}\" will be removed from MotionLab. Your media files are not deleted.") },
            confirmButton = {
                TextButton(onClick = { onDelete(p.id); pendingDelete = null }) { Text("Delete") }
            },
            dismissButton = { TextButton(onClick = { pendingDelete = null }) { Text("Cancel") } }
        )
    }
}

@Composable
private fun ProjectCard(p: Project, onOpen: () -> Unit, onDelete: () -> Unit) {
    val (w, h) = p.canvasSize
    Card(
        modifier = Modifier.fillMaxWidth().clickable(onClick = onOpen),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MLColors.Panel),
        border = BorderStroke(1.dp, MLColors.Stroke)
    ) {
        Row(Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
            Box(Modifier.size(72.dp), contentAlignment = Alignment.Center) {
                val first = p.media.firstOrNull()
                val shape = Modifier.aspectRatio(p.aspect.ratio).clip(RoundedCornerShape(6.dp))
                if (first != null) MediaThumb(first.uri, first.isVideo, 256, shape)
                else Box(shape.background(MLColors.Panel2))
            }
            Spacer(Modifier.width(14.dp))
            Column(Modifier.weight(1f)) {
                Text(p.name, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text("${p.aspect.w}:${p.aspect.h} · $w×$h · ${p.fps} fps", style = MaterialTheme.typography.bodySmall, color = MLColors.Muted)
                Text(
                    "${p.media.size} media · " + SimpleDateFormat("d MMM yyyy", Locale.getDefault()).format(Date(p.createdAt)),
                    style = MaterialTheme.typography.bodySmall, color = MLColors.Muted
                )
            }
            IconButton(onClick = onDelete) { Icon(Icons.Default.Delete, "Delete project", tint = MLColors.Muted) }
        }
    }
}
