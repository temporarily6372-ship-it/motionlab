package com.motionlab.app.ui.screens

import android.content.res.Configuration
import android.net.Uri
import android.view.SurfaceView
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Pause
import androidx.compose.material.icons.filled.PlayArrow
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.clipToBounds
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import androidx.lifecycle.compose.LocalLifecycleOwner
import androidx.media3.common.MediaItem
import androidx.media3.common.Player
import androidx.media3.common.VideoSize
import androidx.media3.exoplayer.ExoPlayer
import androidx.media3.ui.AspectRatioFrameLayout
import androidx.media3.ui.PlayerView
import com.motionlab.app.data.MediaAsset
import com.motionlab.app.data.MediaUtils
import com.motionlab.app.data.Project
import com.motionlab.app.ui.components.MediaThumb
import com.motionlab.app.ui.theme.MLColors
import kotlinx.coroutines.delay
import kotlin.math.max
import kotlin.math.min

/** Preview render quality. Lowers the size of the surface the decoder renders into (saves GPU/heat). */
enum class PreviewQuality(val label: String, val longSide: Int) {
    FULL("Full", 0), P1080("1080p", 1920), P720("720p", 1280), P480("480p", 854), P360("360p", 640)
}

@Composable
fun EditorScreen(
    project: Project,
    onImport: (List<Uri>) -> Unit,
    onRemove: (String) -> Unit,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE
    val player = remember { ExoPlayer.Builder(context).build() }

    var isPlaying by remember { mutableStateOf(false) }
    var positionMs by remember { mutableLongStateOf(0L) }
    var durationMs by remember { mutableLongStateOf(0L) }
    var videoSize by remember { mutableStateOf<VideoSize?>(null) }
    var selectedUri by rememberSaveable { mutableStateOf<String?>(null) }
    var showGrid by rememberSaveable { mutableStateOf(false) }
    var showCenter by rememberSaveable { mutableStateOf(false) }
    var showSafe by rememberSaveable { mutableStateOf(false) }
    var quality by rememberSaveable { mutableStateOf(PreviewQuality.FULL) }

    val selected = project.media.firstOrNull { it.uri == selectedUri } ?: project.media.firstOrNull()
    val isVideo = selected?.isVideo == true

    // Player lifecycle + listener
    DisposableEffect(player) {
        val l = object : Player.Listener {
            override fun onIsPlayingChanged(playing: Boolean) { isPlaying = playing }
            override fun onPlaybackStateChanged(state: Int) {
                if (state == Player.STATE_READY) durationMs = player.duration.coerceAtLeast(0L)
                if (state == Player.STATE_ENDED) isPlaying = false
            }
            override fun onVideoSizeChanged(size: VideoSize) { videoSize = size }
        }
        player.addListener(l)
        onDispose {
            player.removeListener(l)
            player.release()
        }
    }

    // Pause when the app goes to background (saves battery / heat).
    val lifecycleOwner = LocalLifecycleOwner.current
    DisposableEffect(lifecycleOwner) {
        val obs = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_STOP) player.pause() }
        lifecycleOwner.lifecycle.addObserver(obs)
        onDispose { lifecycleOwner.lifecycle.removeObserver(obs) }
    }

    // Load the selected clip into the preview.
    LaunchedEffect(selected?.uri) {
        positionMs = 0L
        durationMs = 0L
        videoSize = null
        val s = selected
        if (s != null && s.isVideo) {
            player.setMediaItem(MediaItem.fromUri(Uri.parse(s.uri)))
            player.prepare()
            player.playWhenReady = false
        } else {
            player.stop()
            player.clearMediaItems()
        }
    }

    // Poll position only while playing.
    LaunchedEffect(isPlaying) {
        while (isPlaying) {
            positionMs = player.currentPosition
            delay(40)
        }
        positionMs = player.currentPosition
    }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenMultipleDocuments()) { uris ->
        if (uris.isNotEmpty()) onImport(uris)
    }
    val (cw, ch) = project.canvasSize

    val monitor: @Composable () -> Unit = {
        Box(Modifier.aspectRatio(project.aspect.ratio).background(Color.Black).clipToBounds()) {
            when {
                isVideo -> AndroidView(
                    modifier = Modifier.fillMaxSize(),
                    factory = { ctx ->
                        PlayerView(ctx).apply {
                            useController = false
                            this.player = player
                            resizeMode = AspectRatioFrameLayout.RESIZE_MODE_FIT
                            setShutterBackgroundColor(android.graphics.Color.BLACK)
                        }
                    },
                    update = { pv ->
                        val sv = pv.videoSurfaceView as? SurfaceView
                        val vs = videoSize
                        if (sv != null) {
                            if (quality == PreviewQuality.FULL || vs == null || vs.width <= 0 || vs.height <= 0) {
                                sv.holder.setSizeFromLayout()
                            } else {
                                val longSide = max(vs.width, vs.height)
                                val scale = min(1f, quality.longSide.toFloat() / longSide)
                                sv.holder.setFixedSize(
                                    max(2, (vs.width * scale).toInt()),
                                    max(2, (vs.height * scale).toInt())
                                )
                            }
                        }
                    }
                )
                selected != null -> MediaThumb(selected.uri, false, 1280, Modifier.fillMaxSize(), ContentScale.Fit)
                else -> Text("Import media to begin", color = MLColors.Muted, modifier = Modifier.align(Alignment.Center))
            }
            GuidesOverlay(showGrid, showCenter, showSafe)
        }
    }

    val transport: @Composable () -> Unit = {
        Row(Modifier.fillMaxWidth().padding(horizontal = 8.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(
                enabled = isVideo,
                onClick = {
                    if (player.playbackState == Player.STATE_ENDED) player.seekTo(0)
                    if (player.isPlaying) player.pause() else player.play()
                }
            ) {
                Icon(if (isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow, if (isPlaying) "Pause" else "Play")
            }
            Text(
                MediaUtils.formatTimecode(positionMs, project.fps),
                style = MaterialTheme.typography.labelLarge, fontWeight = FontWeight.SemiBold
            )
            Slider(
                modifier = Modifier.weight(1f).padding(horizontal = 8.dp),
                enabled = isVideo && durationMs > 0,
                value = if (durationMs > 0) (positionMs.toFloat() / durationMs).coerceIn(0f, 1f) else 0f,
                onValueChange = {
                    positionMs = (it * durationMs).toLong()
                    player.seekTo(positionMs)
                }
            )
            Text(MediaUtils.formatTimecode(durationMs, project.fps), style = MaterialTheme.typography.labelLarge, color = MLColors.Muted)
        }
    }

    val toggles: @Composable () -> Unit = {
        var menu by remember { mutableStateOf(false) }
        Row(
            Modifier.fillMaxWidth().horizontalScroll(rememberScrollState()).padding(horizontal = 12.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            FilterChip(showGrid, { showGrid = !showGrid }, label = { Text("Grid") })
            FilterChip(showCenter, { showCenter = !showCenter }, label = { Text("Center") })
            FilterChip(showSafe, { showSafe = !showSafe }, label = { Text("Safe margins") })
            Box {
                AssistChip(onClick = { menu = true }, label = { Text("Preview: ${quality.label}") })
                DropdownMenu(expanded = menu, onDismissRequest = { menu = false }) {
                    PreviewQuality.entries.forEach { q ->
                        DropdownMenuItem(text = { Text(q.label) }, onClick = { quality = q; menu = false })
                    }
                }
            }
        }
    }

    val mediaPanel: @Composable (Modifier) -> Unit = { mod ->
        Column(mod.background(MLColors.Panel, RoundedCornerShape(topStart = 16.dp, topEnd = 16.dp)).padding(12.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Column(Modifier.weight(1f)) {
                    Text("Media", fontWeight = FontWeight.SemiBold)
                    Text("${project.media.size} items", style = MaterialTheme.typography.bodySmall, color = MLColors.Muted)
                }
                Button(onClick = { picker.launch(arrayOf("video/*", "image/*")) }, shape = RoundedCornerShape(12.dp)) {
                    Icon(Icons.Default.Add, null)
                    Spacer(Modifier.width(6.dp))
                    Text("Import")
                }
            }
            Spacer(Modifier.height(10.dp))
            if (project.media.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Import videos or photos from your device.", color = MLColors.Muted)
                }
            } else {
                LazyVerticalGrid(
                    columns = GridCells.Adaptive(96.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(project.media, key = { it.uri }) { a ->
                        MediaTile(a, a.uri == selected?.uri, { selectedUri = a.uri }, { onRemove(a.uri) })
                    }
                }
            }
        }
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            Column(Modifier.weight(1f)) {
                Text(project.name, fontWeight = FontWeight.SemiBold, maxLines = 1)
                Text("$cw×$ch · ${project.fps} fps", style = MaterialTheme.typography.bodySmall, color = MLColors.Muted)
            }
        }
        if (landscape) {
            Row(Modifier.weight(1f).fillMaxWidth()) {
                Column(Modifier.weight(1.6f).fillMaxHeight()) {
                    Box(Modifier.weight(1f).fillMaxWidth().padding(8.dp), contentAlignment = Alignment.Center) { monitor() }
                    transport()
                    toggles()
                    Spacer(Modifier.height(8.dp))
                }
                mediaPanel(Modifier.weight(1f).fillMaxHeight())
            }
        } else {
            Box(Modifier.weight(1.3f).fillMaxWidth().padding(8.dp), contentAlignment = Alignment.Center) { monitor() }
            transport()
            toggles()
            Spacer(Modifier.height(8.dp))
            mediaPanel(Modifier.weight(0.9f).fillMaxWidth())
        }
    }
}

@Composable
private fun MediaTile(a: MediaAsset, selected: Boolean, onClick: () -> Unit, onRemove: () -> Unit) {
    val shape = RoundedCornerShape(10.dp)
    Box(
        Modifier.aspectRatio(1f).clip(shape)
            .border(if (selected) 2.dp else 1.dp, if (selected) MLColors.Accent else MLColors.Stroke, shape)
            .clickable(onClick = onClick)
    ) {
        MediaThumb(a.uri, a.isVideo, 256, Modifier.fillMaxSize())
        if (a.isVideo) {
            Text(
                MediaUtils.formatDuration(a.durationMs),
                style = MaterialTheme.typography.labelSmall,
                modifier = Modifier.align(Alignment.BottomEnd).padding(4.dp)
                    .background(Color(0xAA000000), RoundedCornerShape(4.dp)).padding(horizontal = 4.dp)
            )
        }
        Box(
            Modifier.align(Alignment.TopEnd).padding(4.dp).size(22.dp)
                .background(Color(0xAA000000), CircleShape).clickable(onClick = onRemove),
            contentAlignment = Alignment.Center
        ) { Icon(Icons.Default.Close, "Remove from project", Modifier.size(14.dp)) }
    }
}

/** Rule-of-thirds grid, center guides and safe-margin frames drawn over the monitor. */
@Composable
private fun GuidesOverlay(grid: Boolean, center: Boolean, safe: Boolean) {
    if (!grid && !center && !safe) return
    androidx.compose.foundation.Canvas(Modifier.fillMaxSize()) {
        val w = size.width
        val h = size.height
        val sw = 1.dp.toPx()
        if (grid) {
            val c = Color.White.copy(alpha = 0.35f)
            for (i in 1..2) {
                drawLine(c, Offset(w * i / 3f, 0f), Offset(w * i / 3f, h), sw)
                drawLine(c, Offset(0f, h * i / 3f), Offset(w, h * i / 3f), sw)
            }
        }
        if (safe) {
            // Action-safe 93% and title-safe 80%
            fun frame(f: Float, c: Color) = drawRect(
                c, topLeft = Offset(w * (1 - f) / 2, h * (1 - f) / 2),
                size = Size(w * f, h * f), style = Stroke(1.5.dp.toPx())
            )
            frame(0.93f, Color(0xFFFFC857).copy(alpha = 0.8f))
            frame(0.80f, Color(0xFFFF5C7A).copy(alpha = 0.8f))
        }
        if (center) {
            val c = MLColors.Accent2.copy(alpha = 0.9f)
            drawLine(c, Offset(w / 2, 0f), Offset(w / 2, h), sw)
            drawLine(c, Offset(0f, h / 2), Offset(w, h / 2), sw)
        }
    }
}
