package com.motionlab.app.data

import org.json.JSONArray
import org.json.JSONObject
import java.util.UUID

enum class Orientation(val label: String) {
    PORTRAIT("Portrait"), LANDSCAPE("Landscape"), SQUARE("Square")
}

enum class AspectPreset(val label: String, val w: Int, val h: Int) {
    P_9_16("9:16 Reels / Shorts", 9, 16),
    P_4_5("4:5 Feed", 4, 5),
    L_16_9("16:9 Widescreen", 16, 9),
    L_21_9("21:9 Cinema", 21, 9),
    L_4_3("4:3 Classic", 4, 3),
    SQ_1_1("1:1 Square", 1, 1);

    val orientation: Orientation
        get() = when {
            h > w -> Orientation.PORTRAIT
            w > h -> Orientation.LANDSCAPE
            else -> Orientation.SQUARE
        }
    val ratio: Float get() = w.toFloat() / h.toFloat()
}

enum class ResolutionPreset(val label: String, val longSide: Int) {
    HD("720p", 1280), FHD("1080p", 1920), UHD("4K", 3840)
}

data class MediaAsset(
    val uri: String,
    val name: String,
    val isVideo: Boolean,
    val durationMs: Long,
    val width: Int,
    val height: Int
) {
    fun toJson(): JSONObject = JSONObject().put("uri", uri).put("name", name).put("isVideo", isVideo)
        .put("durationMs", durationMs).put("width", width).put("height", height)

    companion object {
        fun fromJson(o: JSONObject) = MediaAsset(
            o.getString("uri"), o.optString("name", "media"), o.optBoolean("isVideo", true),
            o.optLong("durationMs", 0), o.optInt("width", 0), o.optInt("height", 0)
        )
    }
}

data class Project(
    val id: String = UUID.randomUUID().toString(),
    val name: String,
    val aspect: AspectPreset,
    val resolution: ResolutionPreset,
    val fps: Int,
    val createdAt: Long = System.currentTimeMillis(),
    val media: List<MediaAsset> = emptyList()
) {
    /** Canvas size in pixels, always even (required by H.264/H.265 encoders). */
    val canvasSize: Pair<Int, Int>
        get() {
            val l = resolution.longSide
            val (w, h) = if (aspect.w >= aspect.h) {
                l to l * aspect.h / aspect.w
            } else {
                l * aspect.w / aspect.h to l
            }
            return (w / 2 * 2) to (h / 2 * 2)
        }

    fun toJson(): JSONObject = JSONObject()
        .put("id", id).put("name", name).put("aspect", aspect.name)
        .put("resolution", resolution.name).put("fps", fps).put("createdAt", createdAt)
        .put("media", JSONArray().also { arr -> media.forEach { arr.put(it.toJson()) } })

    companion object {
        fun fromJson(o: JSONObject): Project {
            val arr = o.optJSONArray("media") ?: JSONArray()
            return Project(
                id = o.getString("id"),
                name = o.getString("name"),
                aspect = AspectPreset.valueOf(o.getString("aspect")),
                resolution = ResolutionPreset.valueOf(o.getString("resolution")),
                fps = o.getInt("fps"),
                createdAt = o.optLong("createdAt"),
                media = (0 until arr.length()).map { MediaAsset.fromJson(arr.getJSONObject(it)) }
            )
        }
    }
}
