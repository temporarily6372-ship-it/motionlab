package com.motionlab.app.data

import android.app.Application
import android.net.Uri
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch

class ProjectViewModel(app: Application) : AndroidViewModel(app) {
    private val repo = ProjectRepository(app)
    private val _projects = MutableStateFlow<List<Project>>(emptyList())
    val projects: StateFlow<List<Project>> = _projects.asStateFlow()

    init {
        viewModelScope.launch(Dispatchers.IO) { _projects.value = repo.load() }
    }

    private fun mutate(transform: (List<Project>) -> List<Project>) {
        val next = transform(_projects.value)
        _projects.value = next
        viewModelScope.launch(Dispatchers.IO) { repo.save(next) }
    }

    fun create(name: String, aspect: AspectPreset, res: ResolutionPreset, fps: Int): Project {
        val p = Project(name = name.trim().ifEmpty { "Untitled Project" }, aspect = aspect, resolution = res, fps = fps)
        mutate { listOf(p) + it }
        return p
    }

    fun delete(id: String) = mutate { list -> list.filterNot { it.id == id } }

    fun importMedia(projectId: String, uris: List<Uri>) {
        viewModelScope.launch(Dispatchers.IO) {
            val items = uris.mapNotNull { MediaUtils.probe(getApplication(), it) }
            if (items.isEmpty()) return@launch
            mutate { list ->
                list.map { p ->
                    if (p.id != projectId) p
                    else p.copy(media = p.media + items.filter { n -> p.media.none { it.uri == n.uri } })
                }
            }
        }
    }

    fun removeMedia(projectId: String, uri: String) = mutate { list ->
        list.map { p -> if (p.id == projectId) p.copy(media = p.media.filterNot { it.uri == uri }) else p }
    }
}
