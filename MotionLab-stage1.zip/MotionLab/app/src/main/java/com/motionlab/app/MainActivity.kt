package com.motionlab.app

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.systemBarsPadding
import androidx.compose.ui.Modifier
import com.motionlab.app.ui.MotionLabApp
import com.motionlab.app.ui.theme.MLColors
import com.motionlab.app.ui.theme.MotionLabTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MotionLabTheme {
                Box(Modifier.fillMaxSize().background(MLColors.Bg).systemBarsPadding()) {
                    MotionLabApp()
                }
            }
        }
    }
}
