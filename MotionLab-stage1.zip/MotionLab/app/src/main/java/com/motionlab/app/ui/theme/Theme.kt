package com.motionlab.app.ui.theme

import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

object MLColors {
    val Bg = Color(0xFF0B0C10)
    val Panel = Color(0xFF14161C)
    val Panel2 = Color(0xFF1C1F27)
    val Stroke = Color(0xFF2A2E39)
    val Accent = Color(0xFF7C6CFF)
    val Accent2 = Color(0xFF22D3EE)
    val Text = Color(0xFFE8EAF0)
    val Muted = Color(0xFF8A90A0)
}

private val scheme = darkColorScheme(
    primary = MLColors.Accent,
    onPrimary = Color.White,
    secondary = MLColors.Accent2,
    background = MLColors.Bg,
    surface = MLColors.Panel,
    surfaceVariant = MLColors.Panel2,
    onSurface = MLColors.Text,
    onBackground = MLColors.Text,
    onSurfaceVariant = MLColors.Muted,
    outline = MLColors.Stroke,
    error = Color(0xFFFF5C7A)
)

@Composable
fun MotionLabTheme(content: @Composable () -> Unit) {
    MaterialTheme(colorScheme = scheme, content = content)
}
