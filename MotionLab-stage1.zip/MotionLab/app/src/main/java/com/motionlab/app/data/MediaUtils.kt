package com.motionlab.app.data

import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.ImageDecoder
import android.media.MediaMetadataRetriever
import android.net.Uri
import android.provider.OpenableColumns
import android.util.LruCache
import kotlin.math.max

object MediaUtils {
    // Memory-bounded thumbnail cache (1/8 of the app heap, sized in KB).
    private val cache = object : LruCache<String, Bitmap>(
        (Runtime.getRuntime().maxMemory() / 1024 / 8).toInt()
    ) {
        override fun sizeOf(key: String, value: Bitmap): Int = value.byteCount / 1024
    }

    /** Reads name, type, duration and size of a picked file. Returns null for unsupported types. */
    fun probe(ctx: Context, uri: Uri): MediaAsset? {
        val cr = ctx.contentResolver
        try {
            cr.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) {
        }
        val mime = cr.getType(uri) ?: return null
        val isVideo = mime.startsWith("video/")
        if (!isVideo && !mime.startsWith("image/")) return null

        var name = "media"
        cr.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use {
            if (it.moveToFirst()) name = it.getString(0) ?: name
        }
        var dur = 0L
        var w = 0
        var h = 0
        if (isVideo) {
            val r = MediaMetadataRetriever()
            try {
                r.setDataSource(ctx, uri)
                dur = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_DURATION)?.toLongOrNull() ?: 0L
                w = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_WIDTH)?.toIntOrNull() ?: 0
                h = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_HEIGHT)?.toIntOrNull() ?: 0
                val rot = r.extractMetadata(MediaMetadataRetriever.METADATA_KEY_VIDEO_ROTATION)?.toIntOrNull() ?: 0
                if (rot == 90 || rot == 270) {
                    val t = w
                    w = h
                    h = t
                }
            } catch (e: Exception) {
                return null
            } finally {
                r.release()
            }
        } else {
            try {
                val src = ImageDecoder.createSource(cr, uri)
                ImageDecoder.decodeBitmap(src) { dec, info, _ ->
                    w = info.size.width
                    h = info.size.height
                    dec.setTargetSampleSize(64) // only the size is needed here
                }.recycle()
            } catch (_: Exception) {
            }
        }
        return MediaAsset(uri.toString(), name, isVideo, dur, w, h)
    }

    fun loadBitmap(ctx: Context, uri: Uri, isVideo: Boolean, maxSide: Int): Bitmap? {
        val key = "$uri#$maxSide"
        cache.get(key)?.let { return it }
        val bmp = try {
            if (isVideo) videoFrame(ctx, uri, maxSide) else image(ctx, uri, maxSide)
        } catch (e: Exception) {
            null
        }
        if (bmp != null) cache.put(key, bmp)
        return bmp
    }

    private fun videoFrame(ctx: Context, uri: Uri, maxSide: Int): Bitmap? {
        val r = MediaMetadataRetriever()
        try {
            r.setDataSource(ctx, uri)
            val f = r.getFrameAtTime(0, MediaMetadataRetriever.OPTION_CLOSEST_SYNC)
                ?: r.getFrameAtTime() ?: return null
            val longSide = max(f.width, f.height)
            if (longSide <= maxSide) return f
            val s = maxSide.toFloat() / longSide
            return Bitmap.createScaledBitmap(
                f, (f.width * s).toInt().coerceAtLeast(1), (f.height * s).toInt().coerceAtLeast(1), true
            )
        } finally {
            r.release()
        }
    }

    private fun image(ctx: Context, uri: Uri, maxSide: Int): Bitmap {
        val src = ImageDecoder.createSource(ctx.contentResolver, uri)
        return ImageDecoder.decodeBitmap(src) { dec, info, _ ->
            dec.allocator = ImageDecoder.ALLOCATOR_SOFTWARE
            val longSide = max(info.size.width, info.size.height)
            dec.setTargetSampleSize((longSide / maxSide).coerceAtLeast(1))
        }
    }

    /** mm:ss:ff timecode using the project frame rate. */
    fun formatTimecode(ms: Long, fps: Int): String {
        val totalSec = ms / 1000
        val frames = ((ms % 1000) * fps / 1000).toInt()
        return "%02d:%02d:%02d".format(totalSec / 60, totalSec % 60, frames)
    }

    fun formatDuration(ms: Long): String {
        val s = ms / 1000
        return "%d:%02d".format(s / 60, s % 60)
    }
}
