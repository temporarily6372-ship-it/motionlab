package com.motionlab.app.data

import android.content.Context
import org.json.JSONArray
import java.io.File

/** Stores projects as JSON in app-private storage. */
class ProjectRepository(context: Context) {
    private val file = File(context.filesDir, "projects.json")

    fun load(): List<Project> {
        if (!file.exists()) return emptyList()
        return try {
            val arr = JSONArray(file.readText())
            (0 until arr.length()).map { Project.fromJson(arr.getJSONObject(it)) }
        } catch (e: Exception) {
            emptyList()
        }
    }

    @Synchronized
    fun save(projects: List<Project>) {
        val arr = JSONArray()
        projects.forEach { arr.put(it.toJson()) }
        val tmp = File(file.parentFile, "projects.json.tmp")
        tmp.writeText(arr.toString())
        tmp.renameTo(file)
    }
}
