package com.motionlab.app.ui.screens

import android.content.res.Configuration
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalConfiguration
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import com.motionlab.app.data.AspectPreset
import com.motionlab.app.data.Orientation
import com.motionlab.app.data.Project
import com.motionlab.app.data.ResolutionPreset
import com.motionlab.app.ui.theme.MLColors

@Composable
fun NewProjectScreen(
    onBack: () -> Unit,
    onCreate: (String, AspectPreset, ResolutionPreset, Int) -> Unit
) {
    var name by remember { mutableStateOf("") }
    var aspect by remember { mutableStateOf(AspectPreset.P_9_16) }
    var res by remember { mutableStateOf(ResolutionPreset.FHD) }
    var fps by remember { mutableIntStateOf(30) }
    val landscape = LocalConfiguration.current.orientation == Configuration.ORIENTATION_LANDSCAPE

    val size = Project(name = "", aspect = aspect, resolution = res, fps = fps).canvasSize

    val preview: @Composable () -> Unit = {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Box(Modifier.height(if (landscape) 200.dp else 150.dp), contentAlignment = Alignment.Center) {
                Box(
                    Modifier.fillMaxHeight().aspectRatio(aspect.ratio)
                        .background(MLColors.Panel2, RoundedCornerShape(8.dp))
                        .border(2.dp, MLColors.Accent, RoundedCornerShape(8.dp)),
                    contentAlignment = Alignment.Center
                ) { Text("${aspect.w}:${aspect.h}", color = MLColors.Muted) }
            }
            Spacer(Modifier.height(8.dp))
            Text("${size.first} × ${size.second} · $fps fps", fontWeight = FontWeight.SemiBold)
        }
    }

    val form: @Composable ColumnScope.() -> Unit = {
        OutlinedTextField(
            value = name, onValueChange = { name = it },
            label = { Text("Project name") }, singleLine = true, modifier = Modifier.fillMaxWidth()
        )
        Section("Orientation")
        ChipGroup(Orientation.entries.toList(), aspect.orientation, { it.label }) { o ->
            aspect = AspectPreset.entries.first { it.orientation == o }
        }
        Section("Aspect ratio")
        ChipGroup(AspectPreset.entries.filter { it.orientation == aspect.orientation }, aspect, { it.label }) { aspect = it }
        Section("Resolution")
        ChipGroup(ResolutionPreset.entries.toList(), res, { it.label }) { res = it }
        Section("Frame rate")
        ChipGroup(listOf(24, 30, 60), fps, { "$it fps" }) { fps = it }
        Spacer(Modifier.height(24.dp))
        Button(
            onClick = { onCreate(name, aspect, res, fps) },
            modifier = Modifier.fillMaxWidth().height(54.dp),
            shape = RoundedCornerShape(16.dp)
        ) { Text("Create Project", fontWeight = FontWeight.SemiBold) }
        Spacer(Modifier.height(16.dp))
    }

    Column(Modifier.fillMaxSize()) {
        Row(Modifier.padding(horizontal = 8.dp, vertical = 4.dp), verticalAlignment = Alignment.CenterVertically) {
            IconButton(onClick = onBack) { Icon(Icons.AutoMirrored.Filled.ArrowBack, "Back") }
            Text("New Project", style = MaterialTheme.typography.titleLarge, fontWeight = FontWeight.SemiBold)
        }
        if (landscape) {
            Row(Modifier.fillMaxSize().padding(horizontal = 20.dp)) {
                Box(Modifier.weight(0.8f).fillMaxHeight(), contentAlignment = Alignment.Center) { preview() }
                Spacer(Modifier.width(20.dp))
                Column(Modifier.weight(1.2f).fillMaxHeight().verticalScroll(rememberScrollState()), content = form)
            }
        } else {
            Column(Modifier.fillMaxSize().padding(horizontal = 20.dp).verticalScroll(rememberScrollState())) {
                Box(Modifier.fillMaxWidth().padding(vertical = 8.dp), contentAlignment = Alignment.Center) { preview() }
                form()
            }
        }
    }
}

@Composable
private fun Section(title: String) {
    Spacer(Modifier.height(18.dp))
    Text(title, style = MaterialTheme.typography.labelLarge, color = MLColors.Muted)
    Spacer(Modifier.height(8.dp))
}

@OptIn(ExperimentalLayoutApi::class)
@Composable
private fun <T> ChipGroup(options: List<T>, selected: T, label: (T) -> String, onSelect: (T) -> Unit) {
    FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
        options.forEach { o ->
            FilterChip(selected = o == selected, onClick = { onSelect(o) }, label = { Text(label(o)) })
        }
    }
}
