package com.motionlab.app.ui.components

import android.graphics.Bitmap
import android.net.Uri
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.produceState
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import com.motionlab.app.data.MediaUtils
import com.motionlab.app.ui.theme.MLColors
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun MediaThumb(
    uri: String,
    isVideo: Boolean,
    maxSide: Int,
    modifier: Modifier = Modifier,
    contentScale: ContentScale = ContentScale.Crop
) {
    val ctx = LocalContext.current
    val bmp by produceState<Bitmap?>(null, uri, maxSide) {
        value = withContext(Dispatchers.IO) { MediaUtils.loadBitmap(ctx, Uri.parse(uri), isVideo, maxSide) }
    }
    Box(modifier.background(MLColors.Panel2)) {
        bmp?.let {
            Image(it.asImageBitmap(), contentDescription = null, modifier = Modifier.fillMaxSize(), contentScale = contentScale)
        }
    }
}
